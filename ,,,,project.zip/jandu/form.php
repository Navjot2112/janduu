<?php
    $name = $_POST['name'];
    $password = $_POST['password'];
